---
title: 个人总结web开发
date: 2014-11-06 17:08:17
tags: other
---

源码爱好者 
http://www.codefans.net/sort/list_2_185_1.shtml       ;
xw素材
http://www.xwcms.net/          ;
慕课网
http://www.imooc.com/        ;
bootcss
http://www.bootcss.com/       ;
后盾网
http://bbs.houdunwang.com/
jquery
http://www.jq22.com/
w3cschool
http://www.w3school.com.cn/
shell基础
http://www.92csz.com/study/linux/12.htm
vim命令
http://www.cnblogs.com/softwaretesting/archive/2011/07/12/2104435.html
快课网
http://www.jikexueyuan.com/
http://www.bootcss.com/p/bootstrap-datetimepicker/
http://code.ciaoca.com/jquery/validation_engine/demo/demoRequired.html
 互联网制图
https://www.processon.com
http协议
http://www.360doc.com/content/10/0930/17/3668821_57590979.shtml
js圆形统计
http://www.helloweba.com/view-blog-264.html
同一个服务器配置多个域名
http://bbs.51cto.com/thread-933764-1-1.html
windows系统激活工具
heu kms
移动web环境（lamp）
usbwebserver
极客网
http://www.jikexueyuan.com/?hmsr=lagou_banner_index
牛客网
http://www.nowcoder.com/947131
麦子学院
http://www.maiziedu.com/

jq表格插件flexgrid、jqgrid

jqgrid

http://www.cnblogs.com/younggun/archive/2012/08/27/2657922.html

jqgrid editrow

http://www.trirand.com/jqgridwiki/doku.php?id=wiki%3ainline_editing

php、web前端

http://www.phpddt.com/

jquery 插件

http://www.jq22.com/

http://www.htmleaf.com/

http://www.mengma.com/

http://www.bubuko.com/infodetail-1072009.html