---
title: python解决html转义
date: 2015-11-16 17:55:45
tags: [python,html]
---
```
import cgi

result['name'] = cgi.escape(name)
```
create By liecol-晓斌

2015.11.16