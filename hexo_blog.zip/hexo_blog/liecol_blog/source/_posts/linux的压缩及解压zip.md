---
title: linux的压缩及解压zip
date: 2015-11-23 18:00:50
categories: 
tags: linux
---

```
zip -r temp.zip temp
unzip all.zip
```
create By liecol-晓斌

2015.11.23