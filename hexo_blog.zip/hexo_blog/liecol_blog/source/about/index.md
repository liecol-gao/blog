---
title: about
date: 2016-07-14 18:00:50
---


名称：liecol-晓斌
招聘网：http://zpw.bloggao.cn
mbb：http://mbb.bloggao.cn
快递网：http://ltkd.bloggao.cn
yin-个人：http://yin.bloggao.cn
原blog地址：http://liecol.bloggao.cn/blog
<i>我也不知道写啥了，少壮不努力，长大搞IT,email：liecol@sina.cn</i>
